<?php

/* article/article.html.twig */
class __TwigTemplate_fb9feaf3551e024ef198f32e027bb284a7c636920d3afe718a63a57b159c8ed5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/article.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ac6d5aac4cc6f7e3d090937abd7e382a5565905ccb1285fc68529dc30a8f69c5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac6d5aac4cc6f7e3d090937abd7e382a5565905ccb1285fc68529dc30a8f69c5->enter($__internal_ac6d5aac4cc6f7e3d090937abd7e382a5565905ccb1285fc68529dc30a8f69c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/article.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ac6d5aac4cc6f7e3d090937abd7e382a5565905ccb1285fc68529dc30a8f69c5->leave($__internal_ac6d5aac4cc6f7e3d090937abd7e382a5565905ccb1285fc68529dc30a8f69c5_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_f257748bd3a142c60c84eb6d9c3e71da5d97a39fda95c367e58772d77c4dd846 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f257748bd3a142c60c84eb6d9c3e71da5d97a39fda95c367e58772d77c4dd846->enter($__internal_f257748bd3a142c60c84eb6d9c3e71da5d97a39fda95c367e58772d77c4dd846_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        // line 4
        echo "
";
        
        $__internal_f257748bd3a142c60c84eb6d9c3e71da5d97a39fda95c367e58772d77c4dd846->leave($__internal_f257748bd3a142c60c84eb6d9c3e71da5d97a39fda95c367e58772d77c4dd846_prof);

    }

    // line 7
    public function block_main($context, array $blocks = array())
    {
        $__internal_66f64c6b7284b796d011932c0fb10100e7d424efda02b2852b6386c85035adef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66f64c6b7284b796d011932c0fb10100e7d424efda02b2852b6386c85035adef->enter($__internal_66f64c6b7284b796d011932c0fb10100e7d424efda02b2852b6386c85035adef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 8
        echo "    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "title", array()), "html", null, true);
        echo "</h2>
                    </header>

                    <p>
                        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "content", array()), "html", null, true);
        echo "
                    </p>

                    <small class=\"author\">
                        ";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "author", array()), "html", null, true);
        echo "
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            <a class=\"btn btn-default btn-xs\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>

";
        
        $__internal_66f64c6b7284b796d011932c0fb10100e7d424efda02b2852b6386c85035adef->leave($__internal_66f64c6b7284b796d011932c0fb10100e7d424efda02b2852b6386c85035adef_prof);

    }

    public function getTemplateName()
    {
        return "article/article.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 26,  76 => 21,  69 => 17,  62 => 13,  55 => 8,  49 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id %}

{% endblock %}

{% block main %}
    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>{{ article.title }}</h2>
                    </header>

                    <p>
                        {{ article.content }}
                    </p>

                    <small class=\"author\">
                        {{ article.author }}
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            <a class=\"btn btn-default btn-xs\" href=\"{{ path('blog_index') }}\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>

{% endblock %}

";
    }
}
