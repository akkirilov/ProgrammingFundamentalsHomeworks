<?php

/* article/create.html.twig */
class __TwigTemplate_6af5e821b2309a013392f64fb3a671b186f812a6c8542d451b7e1e8b2162d9fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/create.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20d15593f72998fd134de7ee6d5c481342e5e1c1adee49a47421c8b429ee2b20 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20d15593f72998fd134de7ee6d5c481342e5e1c1adee49a47421c8b429ee2b20->enter($__internal_20d15593f72998fd134de7ee6d5c481342e5e1c1adee49a47421c8b429ee2b20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_20d15593f72998fd134de7ee6d5c481342e5e1c1adee49a47421c8b429ee2b20->leave($__internal_20d15593f72998fd134de7ee6d5c481342e5e1c1adee49a47421c8b429ee2b20_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_d6d482b34f2e286abe1c71a4871232e65208e3c67e1ae759b1a5619f265ceb00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6d482b34f2e286abe1c71a4871232e65208e3c67e1ae759b1a5619f265ceb00->enter($__internal_d6d482b34f2e286abe1c71a4871232e65208e3c67e1ae759b1a5619f265ceb00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "article_create";
        
        $__internal_d6d482b34f2e286abe1c71a4871232e65208e3c67e1ae759b1a5619f265ceb00->leave($__internal_d6d482b34f2e286abe1c71a4871232e65208e3c67e1ae759b1a5619f265ceb00_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_1d2a8bceb49bb63195420c951b51c7cb4e38f3cd27d6986a9738cb05e1a228b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d2a8bceb49bb63195420c951b51c7cb4e38f3cd27d6986a9738cb05e1a228b6->enter($__internal_1d2a8bceb49bb63195420c951b51c7cb4e38f3cd27d6986a9738cb05e1a228b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_create");
        echo "\" method=\"POST\">
                <fieldset>
                    <legend>New Post</legend>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input class=\"form-control\" id=\"article_title\" name=\"article[title]\" type=\"text\"/>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\" name=\"article[content]\" type=\"text\"></textarea>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 25
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                    ";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
                </fieldset>
            </form>
        </div>
    </div>
";
        
        $__internal_1d2a8bceb49bb63195420c951b51c7cb4e38f3cd27d6986a9738cb05e1a228b6->leave($__internal_1d2a8bceb49bb63195420c951b51c7cb4e38f3cd27d6986a9738cb05e1a228b6_prof);

    }

    public function getTemplateName()
    {
        return "article/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 29,  77 => 25,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'article_create' %}

{% block main %}
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('article_create') }}\" method=\"POST\">
                <fieldset>
                    <legend>New Post</legend>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input class=\"form-control\" id=\"article_title\" name=\"article[title]\" type=\"text\"/>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\" name=\"article[content]\" type=\"text\"></textarea>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('blog_index') }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                    {{ form_row(form._token) }}
                </fieldset>
            </form>
        </div>
    </div>
{% endblock %}";
    }
}
