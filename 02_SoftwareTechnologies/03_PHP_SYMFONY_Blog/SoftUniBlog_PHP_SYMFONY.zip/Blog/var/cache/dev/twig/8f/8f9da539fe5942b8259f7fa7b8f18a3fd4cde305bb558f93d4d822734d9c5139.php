<?php

/* base.html.twig */
class __TwigTemplate_9b7fb3cc72a2c8edbaf0ef13486650fbf7eadddca80d7a94488a58f2df8fe15c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a3b69ca219f03e317c1142c847a197b398d1064bb8b5667b8d3bb370ec8dece = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7a3b69ca219f03e317c1142c847a197b398d1064bb8b5667b8d3bb370ec8dece->enter($__internal_7a3b69ca219f03e317c1142c847a197b398d1064bb8b5667b8d3bb370ec8dece_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 70
        echo "
<div class=\"container body-container\">
    ";
        // line 72
        $this->displayBlock('body', $context, $blocks);
        // line 79
        echo "</div>

";
        // line 81
        $this->displayBlock('footer', $context, $blocks);
        // line 88
        echo "
";
        // line 89
        $this->displayBlock('javascripts', $context, $blocks);
        // line 95
        echo "
</body>
</html>
";
        
        $__internal_7a3b69ca219f03e317c1142c847a197b398d1064bb8b5667b8d3bb370ec8dece->leave($__internal_7a3b69ca219f03e317c1142c847a197b398d1064bb8b5667b8d3bb370ec8dece_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_6ad2d63d897253b9a667c70ab2bab1c6f96df01fb065d027da600e211b77dc5e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ad2d63d897253b9a667c70ab2bab1c6f96df01fb065d027da600e211b77dc5e->enter($__internal_6ad2d63d897253b9a667c70ab2bab1c6f96df01fb065d027da600e211b77dc5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "SoftUni Blog";
        
        $__internal_6ad2d63d897253b9a667c70ab2bab1c6f96df01fb065d027da600e211b77dc5e->leave($__internal_6ad2d63d897253b9a667c70ab2bab1c6f96df01fb065d027da600e211b77dc5e_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5a3571914c945b42e6b40f5d2b262357909fe556247d8314570ead0e6a633cdb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a3571914c945b42e6b40f5d2b262357909fe556247d8314570ead0e6a633cdb->enter($__internal_5a3571914c945b42e6b40f5d2b262357909fe556247d8314570ead0e6a633cdb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_5a3571914c945b42e6b40f5d2b262357909fe556247d8314570ead0e6a633cdb->leave($__internal_5a3571914c945b42e6b40f5d2b262357909fe556247d8314570ead0e6a633cdb_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_1bda14a85580e0fcd6495a709955203263d07b96261c9b5c6aa0c26c609b4093 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bda14a85580e0fcd6495a709955203263d07b96261c9b5c6aa0c26c609b4093->enter($__internal_1bda14a85580e0fcd6495a709955203263d07b96261c9b5c6aa0c26c609b4093_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_1bda14a85580e0fcd6495a709955203263d07b96261c9b5c6aa0c26c609b4093->leave($__internal_1bda14a85580e0fcd6495a709955203263d07b96261c9b5c6aa0c26c609b4093_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_13f2b528eb37fcdf39e099e3eac05a1f2e3572961bc24a95cfef63ce3ee1de7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13f2b528eb37fcdf39e099e3eac05a1f2e3572961bc24a95cfef63ce3ee1de7b->enter($__internal_13f2b528eb37fcdf39e099e3eac05a1f2e3572961bc24a95cfef63ce3ee1de7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        ";
        // line 36
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 37
            echo "                            <li>
                                <a href=\"";
            // line 38
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_create");
            echo "\">
                                    Create Article
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 43
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_profile");
            echo "\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 48
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                    Logout
                                </a>
                            </li>
                        ";
        } else {
            // line 53
            echo "                            <li>
                                <a href=\"";
            // line 54
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("user_register");
            echo "\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"";
            // line 59
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
            echo "\">
                                    LOGIN
                                </a>
                            </li>
                        ";
        }
        // line 64
        echo "                    </ul>
                </div>
            </div>
        </div>
    </header>
";
        
        $__internal_13f2b528eb37fcdf39e099e3eac05a1f2e3572961bc24a95cfef63ce3ee1de7b->leave($__internal_13f2b528eb37fcdf39e099e3eac05a1f2e3572961bc24a95cfef63ce3ee1de7b_prof);

    }

    // line 72
    public function block_body($context, array $blocks = array())
    {
        $__internal_c2b2fd536ad9303a31072e4bebf3dc8793a4ae4fa134b8fcc77223785393870f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2b2fd536ad9303a31072e4bebf3dc8793a4ae4fa134b8fcc77223785393870f->enter($__internal_c2b2fd536ad9303a31072e4bebf3dc8793a4ae4fa134b8fcc77223785393870f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 73
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 75
        $this->displayBlock('main', $context, $blocks);
        // line 76
        echo "            </div>
        </div>
    ";
        
        $__internal_c2b2fd536ad9303a31072e4bebf3dc8793a4ae4fa134b8fcc77223785393870f->leave($__internal_c2b2fd536ad9303a31072e4bebf3dc8793a4ae4fa134b8fcc77223785393870f_prof);

    }

    // line 75
    public function block_main($context, array $blocks = array())
    {
        $__internal_d98e805f777bd02845e5b33b8e6f8f6577e78a9f32262f3959a9ac73553f3247 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d98e805f777bd02845e5b33b8e6f8f6577e78a9f32262f3959a9ac73553f3247->enter($__internal_d98e805f777bd02845e5b33b8e6f8f6577e78a9f32262f3959a9ac73553f3247_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_d98e805f777bd02845e5b33b8e6f8f6577e78a9f32262f3959a9ac73553f3247->leave($__internal_d98e805f777bd02845e5b33b8e6f8f6577e78a9f32262f3959a9ac73553f3247_prof);

    }

    // line 81
    public function block_footer($context, array $blocks = array())
    {
        $__internal_01ad8e91bb822125410d71c93ccdc6ed1faea12ec860f9473ab86e628fff23be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01ad8e91bb822125410d71c93ccdc6ed1faea12ec860f9473ab86e628fff23be->enter($__internal_01ad8e91bb822125410d71c93ccdc6ed1faea12ec860f9473ab86e628fff23be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 82
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_01ad8e91bb822125410d71c93ccdc6ed1faea12ec860f9473ab86e628fff23be->leave($__internal_01ad8e91bb822125410d71c93ccdc6ed1faea12ec860f9473ab86e628fff23be_prof);

    }

    // line 89
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_78b522ba6d5e40e682dd1a44fb1c0a344e5e68166460d2938f7d76ed78f974ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78b522ba6d5e40e682dd1a44fb1c0a344e5e68166460d2938f7d76ed78f974ab->enter($__internal_78b522ba6d5e40e682dd1a44fb1c0a344e5e68166460d2938f7d76ed78f974ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 90
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 93
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_78b522ba6d5e40e682dd1a44fb1c0a344e5e68166460d2938f7d76ed78f974ab->leave($__internal_78b522ba6d5e40e682dd1a44fb1c0a344e5e68166460d2938f7d76ed78f974ab_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  281 => 93,  277 => 92,  273 => 91,  268 => 90,  262 => 89,  250 => 82,  244 => 81,  233 => 75,  224 => 76,  222 => 75,  218 => 73,  212 => 72,  200 => 64,  192 => 59,  184 => 54,  181 => 53,  173 => 48,  165 => 43,  157 => 38,  154 => 37,  152 => 36,  139 => 26,  133 => 22,  127 => 21,  116 => 19,  107 => 14,  102 => 13,  96 => 12,  84 => 11,  74 => 95,  72 => 89,  69 => 88,  67 => 81,  63 => 79,  61 => 72,  57 => 70,  55 => 21,  50 => 19,  43 => 16,  41 => 12,  37 => 11,  30 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}SoftUni Blog{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('blog_index') }}\" class=\"navbar-brand\">SOFTUNI BLOG</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>
                <div class=\"navbar-collapse collapse\">
                    <ul class=\"nav navbar-nav navbar-right\">
                        {% if app.user %}
                            <li>
                                <a href=\"{{ path('article_create') }}\">
                                    Create Article
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('user_profile') }}\">
                                    My Profile
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_logout') }}\">
                                    Logout
                                </a>
                            </li>
                        {% else %}
                            <li>
                                <a href=\"{{ path('user_register') }}\">
                                    REGISTER
                                </a>
                            </li>
                            <li>
                                <a href=\"{{ path('security_login') }}\">
                                    LOGIN
                                </a>
                            </li>
                        {% endif %}
                    </ul>
                </div>
            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2016 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
