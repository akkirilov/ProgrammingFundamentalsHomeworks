<?php

/* article/create.html.twig */
class __TwigTemplate_3714ec1599f820d62176e92770165f25668316e686859e45a8b90c248ed8fae6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/create.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f7fc88bb70f962f4d1fdfdb9ea29a76d679ef1cb3b15973f7c0ad324a69cdf4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7fc88bb70f962f4d1fdfdb9ea29a76d679ef1cb3b15973f7c0ad324a69cdf4b->enter($__internal_f7fc88bb70f962f4d1fdfdb9ea29a76d679ef1cb3b15973f7c0ad324a69cdf4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f7fc88bb70f962f4d1fdfdb9ea29a76d679ef1cb3b15973f7c0ad324a69cdf4b->leave($__internal_f7fc88bb70f962f4d1fdfdb9ea29a76d679ef1cb3b15973f7c0ad324a69cdf4b_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_4957e4f97ece8e67154f3dd30ed7dc6335b08f34db1ef0b075cba30ee723901a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4957e4f97ece8e67154f3dd30ed7dc6335b08f34db1ef0b075cba30ee723901a->enter($__internal_4957e4f97ece8e67154f3dd30ed7dc6335b08f34db1ef0b075cba30ee723901a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "article_create";
        
        $__internal_4957e4f97ece8e67154f3dd30ed7dc6335b08f34db1ef0b075cba30ee723901a->leave($__internal_4957e4f97ece8e67154f3dd30ed7dc6335b08f34db1ef0b075cba30ee723901a_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_4498bfe0b61fee7fc773035af9b7782bcd4fa0261bab97e350e900d053a7bd30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4498bfe0b61fee7fc773035af9b7782bcd4fa0261bab97e350e900d053a7bd30->enter($__internal_4498bfe0b61fee7fc773035af9b7782bcd4fa0261bab97e350e900d053a7bd30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_create");
        echo "\" method=\"POST\">
                <fieldset>
                    <legend>New Post</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input class=\"form-control\" id=\"article_title\" name=\"article[title]\" type=\"text\"/>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\" name=\"article[content]\" type=\"text\"></textarea>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                    ";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
                </fieldset>
            </form>
        </div>
    </div>

";
        
        $__internal_4498bfe0b61fee7fc773035af9b7782bcd4fa0261bab97e350e900d053a7bd30->leave($__internal_4498bfe0b61fee7fc773035af9b7782bcd4fa0261bab97e350e900d053a7bd30_prof);

    }

    public function getTemplateName()
    {
        return "article/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  78 => 26,  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'article_create' %}

{% block main %}
    <div class=\"container body-content span=8 offset=2\">
        <div class=\"well\">
            <form class=\"form-horizontal\" action=\"{{ path('article_create') }}\" method=\"POST\">
                <fieldset>
                    <legend>New Post</legend>

                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_title\">Post Title</label>
                        <div class=\"col-sm-4 \">
                            <input class=\"form-control\" id=\"article_title\" name=\"article[title]\" type=\"text\"/>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label class=\"col-sm-4 control-label\" for=\"article_content\">Content</label>
                        <div class=\"col-sm-6\">
                        <textarea class=\"form-control\" rows=\"6\" id=\"article_content\" name=\"article[content]\" type=\"text\"></textarea>
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <div class=\"col-sm-4 col-sm-offset-4\">
                            <a class=\"btn btn-default\" href=\"{{ path('blog_index') }}\">Cancel</a>
                            <button type=\"submit\" class=\"btn btn-primary\">Submit</button>
                        </div>
                    </div>
                    {{ form_row(form._token) }}
                </fieldset>
            </form>
        </div>
    </div>

{% endblock %}
";
    }
}
