<?php

/* article/article.html.twig */
class __TwigTemplate_fb9feaf3551e024ef198f32e027bb284a7c636920d3afe718a63a57b159c8ed5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "article/article.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c703376fd7675e05d3d0699a2631344b0f14260337804891bf1d7ad9ef1c0034 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c703376fd7675e05d3d0699a2631344b0f14260337804891bf1d7ad9ef1c0034->enter($__internal_c703376fd7675e05d3d0699a2631344b0f14260337804891bf1d7ad9ef1c0034_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "article/article.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c703376fd7675e05d3d0699a2631344b0f14260337804891bf1d7ad9ef1c0034->leave($__internal_c703376fd7675e05d3d0699a2631344b0f14260337804891bf1d7ad9ef1c0034_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_9dfeff0558389a45f91e5958e18caaa51031a42a806b5d4e1d1137e68b374db6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9dfeff0558389a45f91e5958e18caaa51031a42a806b5d4e1d1137e68b374db6->enter($__internal_9dfeff0558389a45f91e5958e18caaa51031a42a806b5d4e1d1137e68b374db6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        // line 4
        echo "
";
        
        $__internal_9dfeff0558389a45f91e5958e18caaa51031a42a806b5d4e1d1137e68b374db6->leave($__internal_9dfeff0558389a45f91e5958e18caaa51031a42a806b5d4e1d1137e68b374db6_prof);

    }

    // line 7
    public function block_main($context, array $blocks = array())
    {
        $__internal_277e9c8722ab8efda0e4462aa5bed40c2667af0203bfc05d7a2629fd21f4a599 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_277e9c8722ab8efda0e4462aa5bed40c2667af0203bfc05d7a2629fd21f4a599->enter($__internal_277e9c8722ab8efda0e4462aa5bed40c2667af0203bfc05d7a2629fd21f4a599_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 8
        echo "    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "title", array()), "html", null, true);
        echo "</h2>
                    </header>

                    <p>
                        ";
        // line 17
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "content", array()), "html", null, true);
        echo "
                    </p>

                    <small class=\"author\">
                        ";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "author", array()), "html", null, true);
        echo "
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            ";
        // line 26
        if (($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()) && ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "isAuthor", array(0 => (isset($context["article"]) ? $context["article"] : $this->getContext($context, "article"))), "method") || $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "isAdmin", array(), "method")))) {
            // line 27
            echo "                            <a class=\"btn btn-success btn-xs\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_edit", array("id" => $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "id", array()))), "html", null, true);
            echo "\">Edit</a>
                            <a class=\"btn btn-danger btn-xs\" href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("article_delete", array("id" => $this->getAttribute((isset($context["article"]) ? $context["article"] : $this->getContext($context, "article")), "id", array()))), "html", null, true);
            echo "\">Delete</a>
                            ";
        }
        // line 30
        echo "                            <a class=\"btn btn-default btn-xs\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>

";
        
        $__internal_277e9c8722ab8efda0e4462aa5bed40c2667af0203bfc05d7a2629fd21f4a599->leave($__internal_277e9c8722ab8efda0e4462aa5bed40c2667af0203bfc05d7a2629fd21f4a599_prof);

    }

    public function getTemplateName()
    {
        return "article/article.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 30,  91 => 28,  86 => 27,  84 => 26,  76 => 21,  69 => 17,  62 => 13,  55 => 8,  49 => 7,  41 => 4,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id %}

{% endblock %}

{% block main %}
    <div class=\"container body-content\">
        <div class=\"row\">
            <div class=\"col-md-12\">
                <article>
                    <header>
                        <h2>{{ article.title }}</h2>
                    </header>

                    <p>
                        {{ article.content }}
                    </p>

                    <small class=\"author\">
                        {{ article.author }}
                    </small>

                    <footer>
                        <div class=\"pull-right\">
                            {% if app.user and (app.user.isAuthor(article) or app.user.isAdmin()) %}
                            <a class=\"btn btn-success btn-xs\" href=\"{{ path('article_edit', {'id': article.id}) }}\">Edit</a>
                            <a class=\"btn btn-danger btn-xs\" href=\"{{ path('article_delete', {'id': article.id}) }}\">Delete</a>
                            {% endif %}
                            <a class=\"btn btn-default btn-xs\" href=\"{{ path('blog_index') }}\">back &raquo;</a>
                        </div>
                    </footer>
                </article>
            </div>
        </div>
    </div>

{% endblock %}

";
    }
}
