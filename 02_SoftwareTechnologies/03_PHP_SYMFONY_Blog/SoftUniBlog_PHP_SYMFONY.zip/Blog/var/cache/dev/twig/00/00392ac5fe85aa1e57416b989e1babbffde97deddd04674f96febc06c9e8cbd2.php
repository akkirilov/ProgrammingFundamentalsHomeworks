<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_41bd596127d9fdc65a3ee0d6472241d990907ebd0aab555a05f5039e96ef09ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f4b2505d545729a531e53f5bdfb1767fab4954cf81c5cfdfb2756b8cb621b9f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f4b2505d545729a531e53f5bdfb1767fab4954cf81c5cfdfb2756b8cb621b9f->enter($__internal_5f4b2505d545729a531e53f5bdfb1767fab4954cf81c5cfdfb2756b8cb621b9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5f4b2505d545729a531e53f5bdfb1767fab4954cf81c5cfdfb2756b8cb621b9f->leave($__internal_5f4b2505d545729a531e53f5bdfb1767fab4954cf81c5cfdfb2756b8cb621b9f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ece3b08523e247b85b584f77a739299a090998f180fb568a374c8e3ac565eebf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ece3b08523e247b85b584f77a739299a090998f180fb568a374c8e3ac565eebf->enter($__internal_ece3b08523e247b85b584f77a739299a090998f180fb568a374c8e3ac565eebf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_ece3b08523e247b85b584f77a739299a090998f180fb568a374c8e3ac565eebf->leave($__internal_ece3b08523e247b85b584f77a739299a090998f180fb568a374c8e3ac565eebf_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_960b0934e11ee6ae89babd8b9e58cde0d5546e1e67a8b0a3599d0bc78344d014 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_960b0934e11ee6ae89babd8b9e58cde0d5546e1e67a8b0a3599d0bc78344d014->enter($__internal_960b0934e11ee6ae89babd8b9e58cde0d5546e1e67a8b0a3599d0bc78344d014_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_960b0934e11ee6ae89babd8b9e58cde0d5546e1e67a8b0a3599d0bc78344d014->leave($__internal_960b0934e11ee6ae89babd8b9e58cde0d5546e1e67a8b0a3599d0bc78344d014_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c2ef1221dfae5e8c9a56450e1faa2dd83d791953d69dccb955f006f3bec9d805 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2ef1221dfae5e8c9a56450e1faa2dd83d791953d69dccb955f006f3bec9d805->enter($__internal_c2ef1221dfae5e8c9a56450e1faa2dd83d791953d69dccb955f006f3bec9d805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_c2ef1221dfae5e8c9a56450e1faa2dd83d791953d69dccb955f006f3bec9d805->leave($__internal_c2ef1221dfae5e8c9a56450e1faa2dd83d791953d69dccb955f006f3bec9d805_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
