<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_bfca35ee90e2b547328ea5401d0fe00c353f26f7a084453d2373114702d37cc1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83d4190111b34844bb1f1b96934b6834608d4c57d0cb7bb9c801606e7c7aa4cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83d4190111b34844bb1f1b96934b6834608d4c57d0cb7bb9c801606e7c7aa4cc->enter($__internal_83d4190111b34844bb1f1b96934b6834608d4c57d0cb7bb9c801606e7c7aa4cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_83d4190111b34844bb1f1b96934b6834608d4c57d0cb7bb9c801606e7c7aa4cc->leave($__internal_83d4190111b34844bb1f1b96934b6834608d4c57d0cb7bb9c801606e7c7aa4cc_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_c58e9a7f11a8339ce0f9c76fa66a3192984c8328e13382de898cc176628076a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c58e9a7f11a8339ce0f9c76fa66a3192984c8328e13382de898cc176628076a4->enter($__internal_c58e9a7f11a8339ce0f9c76fa66a3192984c8328e13382de898cc176628076a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_c58e9a7f11a8339ce0f9c76fa66a3192984c8328e13382de898cc176628076a4->leave($__internal_c58e9a7f11a8339ce0f9c76fa66a3192984c8328e13382de898cc176628076a4_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_1a867407abcef81adcddc07c0a0863424a66769927abd73f645fe8d8063c6bd1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a867407abcef81adcddc07c0a0863424a66769927abd73f645fe8d8063c6bd1->enter($__internal_1a867407abcef81adcddc07c0a0863424a66769927abd73f645fe8d8063c6bd1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_1a867407abcef81adcddc07c0a0863424a66769927abd73f645fe8d8063c6bd1->leave($__internal_1a867407abcef81adcddc07c0a0863424a66769927abd73f645fe8d8063c6bd1_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_4ee6116d9858c933fd11eca3bc2453d341dff215206bc79ca3b69f8eb2a0044b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ee6116d9858c933fd11eca3bc2453d341dff215206bc79ca3b69f8eb2a0044b->enter($__internal_4ee6116d9858c933fd11eca3bc2453d341dff215206bc79ca3b69f8eb2a0044b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_4ee6116d9858c933fd11eca3bc2453d341dff215206bc79ca3b69f8eb2a0044b->leave($__internal_4ee6116d9858c933fd11eca3bc2453d341dff215206bc79ca3b69f8eb2a0044b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
