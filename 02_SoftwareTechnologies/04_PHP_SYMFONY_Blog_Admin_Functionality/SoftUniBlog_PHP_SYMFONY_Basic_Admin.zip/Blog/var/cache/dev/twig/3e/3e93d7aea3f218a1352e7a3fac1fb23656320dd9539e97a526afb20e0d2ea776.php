<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_f789fb6d1972e52097e8455da1cfb60b495f9645e2863126864b2ac5a6b1ac20 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d49f748382e1b0b93f5ae7e539a3f79fe9fd1a19b1d3e745226a8b3ad5f5f9b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d49f748382e1b0b93f5ae7e539a3f79fe9fd1a19b1d3e745226a8b3ad5f5f9b->enter($__internal_3d49f748382e1b0b93f5ae7e539a3f79fe9fd1a19b1d3e745226a8b3ad5f5f9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_3d49f748382e1b0b93f5ae7e539a3f79fe9fd1a19b1d3e745226a8b3ad5f5f9b->leave($__internal_3d49f748382e1b0b93f5ae7e539a3f79fe9fd1a19b1d3e745226a8b3ad5f5f9b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }

    public function getSource()
    {
        return "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
    }
}
