<?php

/* blog/index.html.twig */
class __TwigTemplate_01b8daacf06dddd07da0e823833b17faa3bd7501b8f26dbbc61eaf39371e2cd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c44adbfac6eaa3a2f04012554899bed4c792078b280b68df1169d357de5883a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c44adbfac6eaa3a2f04012554899bed4c792078b280b68df1169d357de5883a5->enter($__internal_c44adbfac6eaa3a2f04012554899bed4c792078b280b68df1169d357de5883a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c44adbfac6eaa3a2f04012554899bed4c792078b280b68df1169d357de5883a5->leave($__internal_c44adbfac6eaa3a2f04012554899bed4c792078b280b68df1169d357de5883a5_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_0f7a692e8a90edf57be2835a34704a5b5e7d5a3b69e2c12734f623a79a3d0d43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0f7a692e8a90edf57be2835a34704a5b5e7d5a3b69e2c12734f623a79a3d0d43->enter($__internal_0f7a692e8a90edf57be2835a34704a5b5e7d5a3b69e2c12734f623a79a3d0d43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        
        $__internal_0f7a692e8a90edf57be2835a34704a5b5e7d5a3b69e2c12734f623a79a3d0d43->leave($__internal_0f7a692e8a90edf57be2835a34704a5b5e7d5a3b69e2c12734f623a79a3d0d43_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block main %}

{% endblock %}
";
    }
}
