<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_7a0e09ca14ac87928a7ae4879addb4e05bb26c74b532483d1bb193a94cae7194 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5101ca0df232a831b4a9233322a7d744c3b4894b1b32fb2bdde8375f07cbb308 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5101ca0df232a831b4a9233322a7d744c3b4894b1b32fb2bdde8375f07cbb308->enter($__internal_5101ca0df232a831b4a9233322a7d744c3b4894b1b32fb2bdde8375f07cbb308_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5101ca0df232a831b4a9233322a7d744c3b4894b1b32fb2bdde8375f07cbb308->leave($__internal_5101ca0df232a831b4a9233322a7d744c3b4894b1b32fb2bdde8375f07cbb308_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_2dc81e96b36d2411781a2d9c5799d7b29cca5b39d48b46f1c03c8fbed2c54437 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2dc81e96b36d2411781a2d9c5799d7b29cca5b39d48b46f1c03c8fbed2c54437->enter($__internal_2dc81e96b36d2411781a2d9c5799d7b29cca5b39d48b46f1c03c8fbed2c54437_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_2dc81e96b36d2411781a2d9c5799d7b29cca5b39d48b46f1c03c8fbed2c54437->leave($__internal_2dc81e96b36d2411781a2d9c5799d7b29cca5b39d48b46f1c03c8fbed2c54437_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_29b085a933bdc7f740c6b1d7d1c3f20d7508daf0c4647cb0f0b8833a6165f381 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29b085a933bdc7f740c6b1d7d1c3f20d7508daf0c4647cb0f0b8833a6165f381->enter($__internal_29b085a933bdc7f740c6b1d7d1c3f20d7508daf0c4647cb0f0b8833a6165f381_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_29b085a933bdc7f740c6b1d7d1c3f20d7508daf0c4647cb0f0b8833a6165f381->leave($__internal_29b085a933bdc7f740c6b1d7d1c3f20d7508daf0c4647cb0f0b8833a6165f381_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_4f2ff1c018eee7b2d0baab22996041d9e835f6e533e9219973e069627f69cfb3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f2ff1c018eee7b2d0baab22996041d9e835f6e533e9219973e069627f69cfb3->enter($__internal_4f2ff1c018eee7b2d0baab22996041d9e835f6e533e9219973e069627f69cfb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_4f2ff1c018eee7b2d0baab22996041d9e835f6e533e9219973e069627f69cfb3->leave($__internal_4f2ff1c018eee7b2d0baab22996041d9e835f6e533e9219973e069627f69cfb3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
